#!/bin/bash

#YML="<yml file name>"
YML="manifest.yml"

SPACE="<project space name>"
#SPACE="Wearables-dev"

#ORGANIZATION="<project organization name>"

cf target -s $SPACE
cf push -f $YML
