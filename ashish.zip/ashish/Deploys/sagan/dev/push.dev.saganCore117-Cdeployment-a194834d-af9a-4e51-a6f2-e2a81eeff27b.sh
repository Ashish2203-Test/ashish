bluemix --apikey lXFwRjAXWc--ElrlE9qTWP45ySpblN0ToC-v9VN99-Dh
cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore117-Cdeployment-a194834d-af9a-4e51-a6f2-e2a81eeff27b.yml
