cf target -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore0-Erez-fb608a6a-96e4-69f6-1a3b-6a9a209aba28.yml
