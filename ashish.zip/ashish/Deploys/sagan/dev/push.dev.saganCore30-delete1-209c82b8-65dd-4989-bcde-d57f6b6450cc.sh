cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore30-delete1-209c82b8-65dd-4989-bcde-d57f6b6450cc.yml
