cf target -o sagan -s dev
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f dev.saganCore.yml


