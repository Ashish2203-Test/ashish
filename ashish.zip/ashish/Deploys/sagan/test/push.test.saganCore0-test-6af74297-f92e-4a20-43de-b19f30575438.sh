cf target -o sagan -s test
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f test.saganCore0-test-6af74297-f92e-4a20-43de-b19f30575438.yml
