cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore34-jtmoore-4f92e404-fb56-4873-afdd-faf95f15bc22.yml
