cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore28-Caesars2-14f29d7d-c6a3-413e-b783-4bd936a3042f.yml
