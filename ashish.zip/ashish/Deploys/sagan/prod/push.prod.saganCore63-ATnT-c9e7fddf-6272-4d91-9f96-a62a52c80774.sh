cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore63-ATnT-c9e7fddf-6272-4d91-9f96-a62a52c80774.yml
