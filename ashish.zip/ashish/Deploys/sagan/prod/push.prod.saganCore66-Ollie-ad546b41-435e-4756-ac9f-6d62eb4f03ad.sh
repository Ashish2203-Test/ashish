cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore66-Ollie-ad546b41-435e-4756-ac9f-6d62eb4f03ad.yml
