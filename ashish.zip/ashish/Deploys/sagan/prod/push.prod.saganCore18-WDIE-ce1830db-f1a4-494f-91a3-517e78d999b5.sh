cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore18-WDIE-ce1830db-f1a4-494f-91a3-517e78d999b5.yml
