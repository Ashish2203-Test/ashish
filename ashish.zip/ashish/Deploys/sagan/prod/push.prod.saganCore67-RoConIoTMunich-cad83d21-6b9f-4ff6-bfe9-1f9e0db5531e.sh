cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore67-RoConIoTMunich-cad83d21-6b9f-4ff6-bfe9-1f9e0db5531e.yml
