cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore25-GSC-820f0734-f647-4406-bb6a-0e316f70bb8a.yml
