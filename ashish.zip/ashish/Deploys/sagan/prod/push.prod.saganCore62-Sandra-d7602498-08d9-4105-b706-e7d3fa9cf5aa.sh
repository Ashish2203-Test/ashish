cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore62-Sandra-d7602498-08d9-4105-b706-e7d3fa9cf5aa.yml
