cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore1-ScottWallace-a8a8b3c2-c50d-4275-ea2d-b28047fb8057.yml
