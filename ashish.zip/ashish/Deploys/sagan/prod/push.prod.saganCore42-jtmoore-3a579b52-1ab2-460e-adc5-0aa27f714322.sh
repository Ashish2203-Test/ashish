cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore42-jtmoore-3a579b52-1ab2-460e-adc5-0aa27f714322.yml
