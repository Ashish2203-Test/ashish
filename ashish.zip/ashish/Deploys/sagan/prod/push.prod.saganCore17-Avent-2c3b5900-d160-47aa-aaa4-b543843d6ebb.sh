cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore17-Avent-2c3b5900-d160-47aa-aaa4-b543843d6ebb.yml
