cf target -o sagan -s prod
cd $( dirname "${BASH_SOURCE[0]}")
cf push -f prod.saganCore31-test-dep-286eaa16-ba74-4f12-b29c-07f64f1dbd66.yml
