/*
 IBM Confidential
 OCO Source Materials
 © Copyright IBM Corp. 2017
 */

var basebl = require('sagan-dev-node-sdk').bl.base;
var BASE = new basebl('route');
const logger = require('../../sagan-logging/logger');
var db = BASE;

db.getRoutingData = function (uri, callback) {
    var self = db;
    self.getAllByAttribute("coreUrl", uri, function (err, results) {
        if (err) {
            logger.error('getRoutingData', null, null, null, "Error - core not found in the DB " + err, null, false);
             
            callback(null);
        } else if (results.length !== 1) {
            logger.info('getRoutingData', null, null, null, "got zero or too many core with the same url: " + results.length, null, false);
             
            callback(null);
        } else {
            callback(results[0]);
        }
    })
};

db.getRoutingDataByAPIKey = function (key, callback) {
    var self = db;
    self.getAllByAttribute("apikey", key, function (err, results) {
        if (err) {
            logger.error('getRoutingDataByAPIKey', null, null, null, "Error - core not found in the DB " + err, null, false);
             
            callback(null);
        } else if (results.length !== 1) {
            logger.info('getRoutingDataByAPIKey', null, null, null, "got zero or too many core with the same url: " + results.length, null, false);
             
            callback(null);
        } else {
            callback(results[0]);
        }
    })
};

db.getRoutingDataByClientID = function (clientID, callback) {
    var self = db;
    self.getAllByAttribute("clientID", clientID, function (err, results) {
        if (err) {
            logger.error('getRoutingDataByClientID', clientID, null, null, "Error - core not found in the DB " + err, null, false);
             
            callback(null);
        } else if (results.length !== 1) {
            logger.info('getRoutingDataByClientID', clientID, null, null, "got zero or too many core with the same url: " + results.length, null, false);
             
            callback(null);
        } else {
            callback(results[0]);
        }
    })
};

db.getAllPersistanceData = function (uri, callback) {
    var self = db;
    self.getAllByAttribute("coreUrl", uri, function (err, results) {
        if (err) {
            logger.error('getAllPersistanceData', null, null, null, "Error - core not found in the DB " + err, null, false);
             
            callback(null);
        } else if (results.length !== 1) {
            logger.info('getAllPersistanceData', null, null, null, "got zero or too many core with the same url: " + results.length, null, false);
             
            callback(null);
        } else {
            callback(results[0].persistentData);
        }
    })
};

db.storePersistanceData = function (data, callback) {
    var self = db;
    self.update(data, callback);
};


module.exports = db;