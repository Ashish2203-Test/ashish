let bl = require('sagan-dev-node-sdk').bl;
let clientID = "69028dc7-b493-8be8-8f73-2704c6e042d2";

bl.configuration.getAllClientConfigurationRaw(clientID, function(docs) {
    bl.configuration.deleteBulk(docs, function(err, result){
        if (err) {
            console.log("err: " + JSON.stringify(err));
        } else {
            console.log(result + " " + docs.length);
        }
    });
});