# sagan-logging
> Logging library for WA

## Installation

1. Copy logging library under your project under "sagan-logging" folder
2. Add a dependency in package.json
```
"sagan-logging": "file:./sagan-logging",
```

## Fields

The library provides following methods
 info()
 debug()
 error()
 silly()
 warn()
 
Each method supports below parameters
- methodName: Method name [Optional]
- clientId: Client identifier [Optional]
- requestId: Unique request id [Optional]
- userId: User identifier [Optional]
- message: Your log data
- custom: Any other custom attributes in JSON format [Optional]
- forCustomer: true if this log record is to be sent to customer's Bluemix account logging instance

## Supported env

The library supports below env
- production-dev
- production-test
- production-staging
- production
- staging [Bluemix staging]

The env name is to be passed as a parameter for init() method of lib
 
## Usage

```js
const logger = require('sagan-logging/logger');
logger.init(env);

logger.info('methodName', 'clientId', 'requestId', 'userId', 'my messsage', {}, true)
logger.error('methodName', 'clientId', 'requestId', 'userId', 'Some critical error', {}, false)
logger.debug('methodName', null, 'requestId', null, 'Checking values...', { 'key': 'value' }, false)
```

### Limitations

The Bluemix logging service Kibana dashboard caps searching of logs data based on the selected plan. If your plan is 500 MB/day, you can search only see first 500 MB of data. Data after that is not visible and searchable.

However any console.log logging done by cf app, the logs are seen via 'cf logs' as well as Kibana irrespective of your plan. Due to this limitation the library does console.log for WA logs and uses logmet client to send logs to customer instance.

The log format for WA can be controlled through env variables WA_LOG_OUTPUT_FORMAT
- If set to 'console' all logs are output to console. This is default
- If set to 'logmet' all logs will be sent to WA Bluemix logging service via logmet client. Here note that no logs are seen on console, if your plan limit exceeds
- If set to 'all', logs are written to console and also sent to WA Bluemix logging service
