/*
IBM Confidential
OCO Source Materials
© Copyright IBM Corp. 2017
*/


'use strict';

const fs = require('fs');
const path = require('path');
const winston = require('winston');

// Application name for logging
var appName = 'sagan';

// Log file settings
const logIncludePid = (process.env.LOGGER_INCLUDE_PID === 'true') ? true : false;
const logFolder = process.env.LOGGER_DIR || './logs';
const logFile = (process.pid && logIncludePid) ? `${logFolder}/${appName}-${process.pid}.log` : `${logFolder}/${appName}.log`;

// Create logs folder if not exists
try {
  fs.mkdirSync(logFolder);
} catch (e) {
  if (e.code != 'EEXIST') {
    console.error(e);
  }
}

// Clear logs folder on start
if (process.env.LOGS_CLEAR === 'true') {
  console.log(`Clear logs folder: ${logFolder}`);
  fs.readdirSync(logFolder).forEach((fileName) => {
    if (path.extname(fileName) === '.log') {
      fs.unlinkSync(`${logFolder}/${fileName}`);
    }
  });
}

let logger = new winston.Logger({
  level: process.env.LOGGER_LEVEL || 'info',
  rewriters: [
    (level, msg, meta) => {
      return meta;
    }
  ],
  transports: [
    new (winston.transports.File)({
      filename: logFile
    }),
    new (winston.transports.Console)({
      json: false,
      timestamp: true,
      colorize: true
    })
  ]
});

module.exports = logger;
